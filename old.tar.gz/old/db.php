<?php
$db_svr  = "db1.acm.uiuc.edu";
$db_user = "sigmil";
$db_pwd  = "leetHacker";
?>
