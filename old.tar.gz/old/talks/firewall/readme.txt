
iptables is a home router setup with two interface and routing.  It's in
iptables-save format, and can be dropped into /etc/sysconfig/iptables
on an FC/Redhat box.

rc.firewall is a distro-agnostic firewall script, fit for a machine
that's not doing routing.


