<div class="header">
<a href="index.php"><span><img src="img/new_logo.png" alt="sigmillogo"/></span></a>
</div>

<div class="stripes"><span></span></div>
<div class="nav">
    <a href="index.php">Main</a>
    <a href="projects.php">Projects</a>
    <a href="talks.php">Talks</a>
    <a href="books.php">Books</a>
    <a href="links.php">Links</a>
    <a href="hack08.php">Hack08</a>
    <div class="clearer"><span></span></div>
</div>
<div class="stripes"><span></span></div>
