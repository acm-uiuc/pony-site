<div class="footer">
	<div class="bottom">
		<span class="left">These are not the droids you're looking for.</span>
		<span class="right"><a href="/sigpony">SIGPony</a></span>
		<div class="clearer"><span></span></div>
	</div>
</div>

