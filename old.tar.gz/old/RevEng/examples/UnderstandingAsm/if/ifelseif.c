#include <stdio.h>

int main(int argc, char **argv)
{
    int a;
 
    if(a < 0)
    {
        printf("A is less than 0\n");
    }
    else if(a == 0)
    {
        printf("A is 0\n");
    }
    else
    {
        printf("A > 0\n");
    }
    
    printf("Leaving main\n");
    
}
