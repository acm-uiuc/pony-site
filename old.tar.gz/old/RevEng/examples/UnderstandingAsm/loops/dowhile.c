
#include <stdio.h>

int main(int argc, char **argv)
{
    int i; 

    i = 0;
    do {
        printf("%d\n", i);
        i++;
    } while(i < 10);
}
