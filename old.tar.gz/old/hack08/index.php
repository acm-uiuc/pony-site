<?php
header('Location:http://www.acm.uiuc.edu/sigmil/hack08.php');
die();
?>
